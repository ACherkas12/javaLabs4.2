package IDZ8_xml;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class Main {
    private static final String url = "https://www.nbrb.by/Services/XmlExRates.aspx";
    private static final ArrayList<Currency> currSax = new ArrayList<>();
    private static final ArrayList<Currency> currStax = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        URL obj = new URL(url);
        HttpURLConnection connection = (HttpURLConnection) obj.openConnection();
        int responseCode = connection.getResponseCode();
        System.out.println("Response code: " + responseCode + "\n");
        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        ArrayList<Currency> currDom = DOM(response);
        SAX();
        STAX();
        System.out.println("DOM result:");
        System.out.println(currDom + "\n\n");
        System.out.println("SAX result:");
        System.out.println(currSax + "\n\n");
        System.out.println("StAX result:");
        System.out.println(currStax);
    }

    public static void STAX() {
        XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
        XMLEventReader reader;
        try {
            InputStream in = new URL(url).openStream();
            reader = xmlInputFactory.createXMLEventReader(in);
            Currency currency = null;
            while (reader.hasNext()) {
                XMLEvent nextEvent = reader.nextEvent();
                if (nextEvent.isStartElement()) {
                    StartElement startElement = nextEvent.asStartElement();
                    switch (startElement.getName().getLocalPart()) {
                        case "Currency" -> {
                            currency = new Currency();
                            currency.setId(Integer.parseInt(
                                    startElement.getAttributeByName(new QName("Id")).getValue())
                            );
                        }
                        case "NumCode" -> {
                            nextEvent = reader.nextEvent();
                            currency.setNumCode(Integer.parseInt(nextEvent.asCharacters().getData()));
                        }
                        case "CharCode" -> {
                            nextEvent = reader.nextEvent();
                            currency.setCharCode(nextEvent.asCharacters().getData());
                        }
                        case "Scale" -> {
                            nextEvent = reader.nextEvent();
                            currency.setScale(Integer.parseInt(nextEvent.asCharacters().getData()));
                        }
                        case "Name" -> {
                            nextEvent = reader.nextEvent();
                            currency.setName(nextEvent.asCharacters().getData());
                        }
                        case "Rate" -> {
                            nextEvent = reader.nextEvent();
                            currency.setRate(Double.parseDouble(nextEvent.asCharacters().getData()));
                        }
                    }
                }
                if (nextEvent.isEndElement()) {
                    EndElement endElement = nextEvent.asEndElement();
                    if (endElement.getName().getLocalPart().equals("Currency")) {
                        currStax.add(currency);
                    }
                }
            }
        } catch (XMLStreamException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void SAX() {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        SAXParser parser;
        try {
            parser = factory.newSAXParser();
            XMLHandler handler = new XMLHandler();
            parser.parse(url, handler);
        } catch (ParserConfigurationException | SAXException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static class XMLHandler extends DefaultHandler {
        private final StringBuilder elementValue = new StringBuilder();
        Currency currentCurrency;

        @Override
        public void characters(char[] ch, int start, int length) {
            elementValue.append(ch, start, length);
        }

        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) {
            elementValue.setLength(0);
            if (qName.equals("Currency")) {
                currentCurrency = new Currency(Integer.parseInt(attributes.getValue("Id")));
            }
        }

        @Override
        public void endElement(String uri, String localName, String qName) {
            switch (qName) {
                case "NumCode" -> currentCurrency.setNumCode(Integer.parseInt(elementValue.toString()));
                case "CharCode" -> currentCurrency.setCharCode(elementValue.toString());
                case "Scale" -> currentCurrency.setScale(Integer.parseInt(elementValue.toString()));
                case "Name" -> currentCurrency.setName(elementValue.toString());
                case "Rate" -> currentCurrency.setRate(Double.parseDouble(elementValue.toString()));
                case "Currency" -> currSax.add(currentCurrency);
            }
        }
    }

    public static ArrayList<Currency> DOM(StringBuilder xml) {
        ArrayList<Currency> currencies = new ArrayList<>();
        Document doc = null;
        try {
            doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
                    .parse(new InputSource(new StringReader(xml.toString())));
        } catch (SAXException | IOException | ParserConfigurationException e) {
            throw new RuntimeException(e);
        }
        NodeList errNodes = doc.getElementsByTagName("Currency");
        for (int i = 0; i < errNodes.getLength(); i++) {
            Element el = (Element) errNodes.item(i);
            currencies.add(new Currency(Integer.parseInt(el.getAttribute("Id")),
                    Integer.parseInt(el.getElementsByTagName("NumCode").item(0).getTextContent()),
                    el.getElementsByTagName("CharCode").item(0).getTextContent(),
                    Integer.parseInt(el.getElementsByTagName("Scale").item(0).getTextContent()),
                    el.getElementsByTagName("Name").item(0).getTextContent(),
                    Double.parseDouble(el.getElementsByTagName("Rate").item(0).getTextContent()))
            );
        }
        return currencies;
    }
}

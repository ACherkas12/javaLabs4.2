package IDZ6_collections;

public class Number implements Comparable<Number> {
    private double num;

    public Number(double num) {
        this.num = num;
    }

    public double getNum() {
        return num;
    }

    public void setNum(double num) {
        this.num = num;
    }

    @Override
    public String toString() {
        return "" + num;
    }

    @Override
    public int compareTo(Number o) {
        return getNum() > o.getNum() ? 1 : -1;
    }
}

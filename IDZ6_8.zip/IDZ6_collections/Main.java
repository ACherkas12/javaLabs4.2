package IDZ6_collections;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {
        FileReader reader;
        FileWriter writer;
        try {
            reader = new FileReader("src/IDZ5_collections/numbers.txt");
            Scanner scanner = new Scanner(reader);
            TreeSet<Number> nums = new TreeSet<>();
            System.out.println("Numbers in file:");
            while (scanner.hasNext()) {
                double d = scanner.nextDouble();
                System.out.print(d + "  ");
                nums.add(new Number(d));
            }
            System.out.println("\nNumbers in collection:");
            System.out.println(nums);

            Number[] ns = new Number[nums.size()];
            ns = nums.toArray(ns);
            int l = ns.length;
            writer = new FileWriter("src/IDZ5_collections/out.txt");
            while (l != 1) {
                for (int c = 0; c < l; c++) {
                    writer.write(ns[c].getNum() + " ");
                }
                writer.write('\n');
                int curr = 0;
                for (int i = 0; i < l; i += 2) {
                    if (l != i + 1)
                        ns[curr] = new Number(ns[i].getNum() + ns[i + 1].getNum());
                    else {
                        ns[curr] = new Number(ns[i].getNum());
                    }
                    curr += 1;
                }
                l = (l % 2 == 0 ? l / 2 : l / 2 + 1);
            }
            writer.write(ns[0].getNum() + "");
            System.out.println("Result file: out.txt");
            writer.close();
            reader.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
